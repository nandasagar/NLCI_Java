package driver;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import dbOperations.Operations;
import domain.Users;

public class Driver {
	
	 //StringBuffer in java is used to create modifiable String objects which is given by user at Runtime.
	 static InputStreamReader ir=new InputStreamReader(System.in); static
	 BufferedReader br=new BufferedReader(ir);
	 
	public static void main(String[] args) throws Exception {
		 
		//the while loop will run forever as value is true. it can be terminated using  System.exit(0)
		while(true)
		{
		System.out.println("************LIC DOMAIN*****************");
		System.out.println("Enter The  Operations");
		System.out.println("1. Insert  Operations");
		System.out.println("2. Display Operations");
		System.out.println("3. Update  Operations");
		System.out.println("4. Delete  Operations");
		String x1=br.readLine();
		 try{
			    int n=Integer.parseInt(x1);
			  //switch statement is used for selection control mechanism
			    switch(n)                        
				{
				case 1: insert();
				break;
				case 2: display();
				break;
				case 3: update();
				break;
				case 4: delete();
				break;
				case 0: System.exit(0);
				break;
				default: System.out.print("Invalid No:");
				}
		 }catch(Exception e)
		 { 
			System.out.println("Enter Valid Number");
		 }		
		}
	}

        // insert() method is used to insert values in db_lic data base.
	private static void insert() throws Exception {
		// Creating object ui of class UserInputs
		UserInputs ui=new UserInputs();
		//Creating Users object and calling inputAll() method through UserInputs object ui and assigning to Users object u.
		Users u=ui.inputAll();
		//passing Users object to insertUsers1() method of Operations Class and which on success returns an Int Value
		int res=Operations.insertUsers1(u);
	
		if(res!=0)
		{
			System.out.println("Data Inserted!!");
			System.out.println();
		}
	
	}
	
	// delete() method is used to delete particular row in db_lic data base based on policy number.
	private static void delete() throws Exception{

			System.out.println("Enter policy No to Delete the Record");
			// Creating object ui of class UserInputs
			UserInputs ui=new UserInputs();
			//Creating Users object and calling inputPnum() method through UserInputs object ui and assigning to Users object u.
			Users u=ui.inputPnum();	
			//passing Users object to delete() method of Operations Class.
			Operations.delete(u);
			
	}

	
	// update() method is used to update values of premium type in db_lic data base based on policy number.
	private static void update() throws Exception {
		
	    	// Creating object ui of class UserInputs
			UserInputs ui=new UserInputs();
			//Creating Users object and calling inputPnum() method through UserInputs object ui and assigning to Users object u.
			Users u=ui.input_Pnum_Ptype();
			//passing Users object to update() method of Operations Class and which on success returns an Int Value.
			int r=Operations.update(u);
			if(r==0)
			{
				System.out.println("Updation Failed!!");
			}

		
	}

	// display() method is used to display particular row in db_lic data base based on policy number.
	private static void display() throws Exception {
		

			System.out.println("Enter policy No to Fetch the Record");
			// Creating object ui of class UserInputs
			UserInputs ui=new UserInputs();
			//Creating Users object and calling inputPnum() method through UserInputs object ui and assigning to Users object u.
			Users u=ui.inputPnum();
			//passing Users object to delete() method of Operations Class.
			Operations.display(u);	
	
		
	}

	

}
