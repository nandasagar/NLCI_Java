package dbOperations;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import domain.Users;

public class Operations {
	final static String url = "jdbc:mysql://localhost:3306/db_lic"; 
    final  static String user = "root"; 
    final static  String pass = "Nanda$105"; 
     static int n1;
    

    /*This insertUsers1(Users u) used accepts Users object u as parameter.  
	Establishes Connection with Sql Server and Inserts 5 Values into table  tb_users of db_lic database
	using Prepared Statement  */
	public static int insertUsers1(Users u) throws Exception 
	{
		  //Creating the connection 
		Connection con=null;
		Statement stmt = null;
		ResultSet rs=null;
			
			try 
			{
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection(url,user,pass);
				stmt= con.createStatement();
			} 
			catch (ClassNotFoundException ex) 
			{
				
				ex.printStackTrace();
			}   
		    String sql="insert into tb_users "
					+ "(Policy_Name ,Policy_Holder_Name ,Policy_Start_Date ,Premium_Amount ,Premium_Type) values" + 
					"( ?,?,?,?,?)";
			PreparedStatement pt = con.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			
			pt.setString(1,u.getPname());
			pt.setString(2,u.getHname());
			pt.setString(3,u.getPdate());
			pt.setFloat(4,u.getPremium_amount());
			pt.setString(5,u.getPremium_type());
			final int r=pt.executeUpdate();
			
			rs = pt.getGeneratedKeys();
			if(rs != null && rs.next()){
				System.out.println();
				System.out.println();
				System.out.println("Congrats!! your Generated policy number: "+rs.getInt(1));
		    	System.out.println("**************************************");
				
			}
			
			stmt.close();		
		    con.close();
		    return r;
			
		}

	
	  /*This display(Users u) Method  accepts Users object u as parameter.
	    Establishes Connection with Sql Server and Fetchs All Values into table  tb_users of db_lic database
		using Prepared Statement  */
	public static void display(Users u) throws SQLException {
		
		Statement stmt = null;
		ResultSet rs=null;
		Connection con=null;
			try 
			{
				
				
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection(url,user,pass);
				
		    String sql="select * from tb_users where Policy_Number = ?";
			PreparedStatement pt = con.prepareStatement(sql);		
			pt.setInt(1,u.getPno());
			
			  rs = pt.executeQuery();
			 
			  if(rs.next()){
	           //Retrieve by column name
				  
	           int pno= rs.getInt("Policy_Number");
	           String pname = rs.getString("Policy_Name");
	           String phname = rs.getString("Policy_Holder_Name");  
	           String pdate=rs.getString("Policy_Start_Date");
	           float pamount = rs.getFloat("Premium_Amount");
	           String ptype = rs.getString("Premium_Type");


	           //Display values
	           System.out.println("Policy_Number:      " + pno);
	           System.out.println("Policy_Name:        " + pname);
	           System.out.println("Policy_Holder_Name: " + phname);
	           System.out.println("Policy_Start_Date:  " + pdate);
	           System.out.println("Premium_Amount:     " + pamount);
	           System.out.println("Premium_Type:       " + ptype);
	       
	        } 
			  else
			  {
				  System.out.println("Invalid!! .Please Enter valid Policy No:");
			  }
			} 
			catch (Exception ex) 
			{
				System.out.println(" Enter Valid Policy No");
				//ex.printStackTrace();
			}   
			
	        finally {
	        	 rs.close();
	             con.close();
		      }
			
			
				
			}

	 /*This update(Users u) Method accepts Users object u as parameter. Establishes
       Connection with Sql Server and updates Premium_Type based on users Policy_Number 
       in the table  tb_users of db_lic database using Prepared Statement  */
	public static int update(Users u) throws SQLException {
		
		Connection con=null;
		Statement stmt = null;
		
			
			try 
			{
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection(url,user,pass);
			} 
			catch (Exception ex) 
			{
				
				ex.printStackTrace();
			}  	
		    String sql="update tb_users SET Premium_Type=?   where Policy_Number = ?";
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setString(1,u.getPremium_type());
			pt.setInt(2,u.getPno());
			System.out.println(u.getPremium_type());
			System.out.println(u.getPno());
		//	System.out.println(u.getPno());
			
	    		int r = pt.executeUpdate();
	    		if(r!=0)
				{
			        System.out.println("Updated");
					display(u);
				}

	             con.close();
		      
			return r;
				
			}

	
	/*This delete(Users u) Method accepts Users object u as parameter.Establishes 
	  Connection with Sql Server and deletes particular row based on users Policy_Number 
      in the table  tb_users of db_lic database using Prepared Statement  */
	public static void delete(Users u) throws Exception {
		
	    Connection con=null;
		Statement stmt = null;
		
		
		  try
	      { 
	          DriverManager.registerDriver(new com.mysql.jdbc.Driver()); 
	
	          //Reference to connection interface 
	          con = DriverManager.getConnection(url,user,pass); 
	
	          Statement st = con.createStatement(); 
	          PreparedStatement pt = con.prepareStatement(" delete from tb_users  where Policy_Number = ?");	
	
	          pt.setInt(1,u.getPno());
	          int r = pt.executeUpdate();
	  		
		  		
		  	    if(r!=0)
		  	    {
		  	    	System.out.println("Deleted");
		  	    }
		  	    else
		  	    {
		  	    	System.out.println("Invalid portal");
		  	    }
	  		}
		  catch (Exception ex) 
			{
				
				ex.printStackTrace();
			}   
	     
	      finally {
	      	
	           con.close();
		      }
				
			}

}
	
	
	

