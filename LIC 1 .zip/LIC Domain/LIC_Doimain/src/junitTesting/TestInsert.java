package junitTesting;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import dbOperations.Operations;
import domain.Users;

public class TestInsert {

	// Testing the Functionality with the Manually giving Inputs to database.
	@Test
	public  void test_Manual_Insertion() throws Exception {
	
	 Users u = new Users("LIC Jevan ","kholi","2000-01-01","yearly",1000.f);
	 System.out.println(" Manual Testng By passing Values Manually");	
		
	  int res =  Operations.insertUsers1(u); // create and insert operation are same
	 	
	  assertEquals(1,res); 
	  
	  if(res==1)	  
	  {	  
	  System.out.println(" ********Manual Based Testing Passed**********"); 
	  System.out.println();
	  }
	}


	/* Generates ERROR!!! 
	 Testing the Functionality with the Manually giving Faulty Input(Date) to database*/
	@Test
	public  void test_Error_Insertion() throws Exception {
	try {
	 Users u = new Users("LIC Jevan ","kholi","20001-01-01","year",1000.f);
	 System.out.println(" Manual passing Faulty Inputs: ERROR DATE");	
		
	  int res =  Operations.insertUsers1(u); // create and insert operation are same
	 	
	  assertEquals(1,res); 
	}
	catch(Exception e){
		System.out.println("Inavlid Values");
	}
  }
	
}


