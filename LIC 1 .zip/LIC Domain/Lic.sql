create database db_lic;
use db_lic;
create table tb_users(Policy_Number Integer AUTO_INCREMENT , 
	Policy_Name  varchar(40) not null,
	Policy_Holder_Name varchar(40) not null,
	Policy_Start_Date date not null , 
	Premium_Amount  float not null,
	Premium_Type varchar(40) not null,primary key(Policy_Number));

select *from tb_users;