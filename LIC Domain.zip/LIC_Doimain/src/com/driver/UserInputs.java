package com.driver;


import java.io.IOException;

import java.util.Scanner;

import com.domain.Users;

public class UserInputs {
	
	
	static Scanner scan=new Scanner(System.in);
	static String pname;
	static String hname;
	static String pdate;
	static String premium_type;
	static float premium_amount;
	
	/*This  inputPnum() Method is used to Get 1 input from user i.e pnum 
	and Assign  the value to POJO class i.e Users class to set the values 
	by passing through Single Parameterized Constructor Users(pno) .
	and returns the Users class object u to the Driver class*/
	public Users inputPnum() throws IOException {
		
		Users u=new Users();
		u.setPno(scan.nextInt());
		return(u);
		
	}
	
	
	/*This  input_Pnum_Ptype() Method is used to Get 2 inputs from user i.e pnum and ptype 
	and Assign both the values to POJO class i.e Users class
	to set the values by passing through Parameterized Constructor Users(premium_type,pno)
	and returns the Users class object u to the Driver class*/
	public Users input_Pnum_Ptype() throws IOException {
		
		System.out.println("Enter policy No to which Policy Type should be Updated!!");
		
		int pno=scan.nextInt();
		System.out.println("Enter  premium  type :");
		System.out.println("Enter 1 for quarterly");
		System.out.println("Enter 2 for half yearly");
		System.out.println("Enter 3 for  yearly");
		
		 int n1=scan.nextInt();
		 switch(n1)
		 {
		 case  1:premium_type="quarterly";
		 break;
		 case  2:premium_type="half yearly";
		 break;
		 case  3:premium_type="yearly";
		 break;
		 default: System.out.println("Invalid Value!! please Select valid premium type");
		 			
		}
		Users u=new Users(premium_type,pno);
		
		
		
		return u;
	}

	
	/*This  inputAll() Method is used to Get All 5 inputs from user i.e pname,hname,pdate,premium_type,premium_amount. 
	and Assign 5  values to POJO class i.e Users class
	to set the values by passing through Parameterized Constructor Users(pname,hname,pdate,premium_type,premium_amount)
	and returns the Users class object u to the Driver class*/
	public Users inputAll() {
		
		try {
		
		System.out.println("Choose one policy:");
		System.out.println();
		System.out.println("Enter 1 for LIC e-Term Plan");
		System.out.println("Enter 2 for LIC Jeevan Arogya Plan");
		System.out.println("Enter 3 for LIC Jeevan Saathi Plan");
		System.out.println("Enter 4 for LIC Market Plus I Plan");
		System.out.println("Enter 5 for LIC Education Plan");
		System.out.println("Enter 6 for LIC Travel Plan");
		System.out.println("Enter 7 for LIC Retirement Plan");
		System.out.println("Enter 8 to Manually Enter Other Plan");
		
		int n1=scan.nextInt();
		 switch(n1)
		 {
			 case  1:pname="LIC e-Term Plan";
			 break;
			 case  2:pname="LIC Jeevan Arogya Plan";
			 break;
			 case  3:pname="LIC Jeevan Saathi Plan";
			 break;
			 case  4:pname="LIC Market Plus I Plan";
			 break;
			 case  5:pname="LIC Education Plan ";
			 break;
			 case  6:pname="LIC Travel Plan";
			 break;
			 case  7:pname="LIC Retirement Plan";
			 break;
			 case 8:System.out.println("Enter policy name");
			        pname=scan.next();
			        break;
			 
			 
			 default: System.out.println("Invalid Value!! please Select valid policy name"); 			
		}
	}
		
		catch(Exception e)
			{
				System.out.println("Invalid policy name  :"+e);
				System.out.println("  ");inputAll();
			}
		
		//=================================================================
		
		try {
		System.out.println("Enter policy holder name:");
		hname=scan.next(); 
			}
		catch(Exception e)
			{
				System.out.println("exception occured :"+e);
			
			}
		
		//=================================================================
		try {
		System.out.println("Enter policy date:(yyyy-mm-dd)"); 
		pdate=scan.next(); 	
			}
		catch(Exception e)
	    	{
					System.out.println("exception occured :"+e);
			}
	
		try {
			System.out.println("Enter  premium  type :");
			System.out.println("Enter 1 for quarterly");
			System.out.println("Enter 2 for half yearly");
			System.out.println("Enter 3 for  yearly");
			
			 
			 int n1=scan.nextInt(); ;
				 switch(n1)
				 {
					 case  1:premium_type="quarterly";
					 break;
					 case  2:premium_type="half yearly";
					 break;
					 case  3:premium_type="yearly";
					 break;
					 default: System.out.println("Invalid Value!! please Select valid premium type"); 			
				}
			}
		catch(Exception e)
			{
				System.out.println("exception occured :"+e);
			}
		//==================================================================
		try {
		System.out.println("Enter  premium  amount :");
		 
		 premium_amount=scan.nextFloat();
		
			}
		catch(Exception e)
			{
				System.out.println("exception occured :"+e);
			}
		Users u=new Users(pname,hname,pdate,premium_type,premium_amount);

		return u;
	
	
	
	}

}
