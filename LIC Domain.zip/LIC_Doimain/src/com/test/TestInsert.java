package com.test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import com.dbcon.DbOperations;
import com.domain.Users;

public class TestInsert{
	/* Testing the Functionality with the Manually giving Inputs to the Users 
	   constructor and Inserts Values into table  tb_users of db_lic database	*/
	@Test
	public  void testManualInsertion() throws Exception {
	
	  Users u = new Users("LIC Jevan ","KLRahul","2000-01-01","yearly",10000.f);
	  System.out.println(" Manual Testng By passing Values Manually");	 	
	  int res =  DbOperations.insertUsers(u); // create and insert operation are same	 	
	  assertEquals(1,res); 
	  if(res==1) System.out.println(" ********Manual Based Testing Passed**********"); 	  
	}
	/* Generates ERROR!!! 
	   Testing the Functionality with the Manually giving faulty Inputs to the Users 
	   constructor and Inserts Values into table  tb_users of db_lic database	*/
	@Test
	public  void testErrorInsertion() throws Exception 
		{
		try {Users u = new Users("LIC Jevan ","kholi","20001-01-01","year",1000.f);
			 System.out.println(" Manual passing Faulty Inputs: ERROR DATE");					
			  int res =   DbOperations.insertUsers(u); // create and insert operation are same		 	
			  assertEquals(1,res); 
			}
			catch(Exception e){
				System.out.println("Inavlid Values");
			}
		}
	}


