package com.dbcon;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.domain.Users;

public class PreparedClass {
	//accepts connection object, SQL Query,and user Object as a parameter.and sets to values & returns PreparedStatement object.
	static PreparedStatement pt;
	public static PreparedStatement insert(Connection con,String s,Users u) 
	{		
		try {
			pt = con.prepareStatement(s,Statement.RETURN_GENERATED_KEYS);
			pt.setString(1,u.getPname());
			pt.setString(2,u.getHname());
			pt.setString(3,u.getPdate());
			pt.setFloat(4,u.getPremium_amount());
			pt.setString(5,u.getPremium_type());
			
		} catch (SQLException e) {	
			System.out.println("Error!!");
			e.printStackTrace();
		}
		return pt;	
	}
	
	
	//accepts connection object, SQL Query,and user Object as a parameter.and sets to values & returns PreparedStatement object.
	public static PreparedStatement display(Connection con, String dis, Users u){	
		try {
			pt = con.prepareStatement(dis);
			pt.setInt(1,u.getPno());
		} catch (SQLException e) {
			System.out.println("Error!!");
			e.printStackTrace();
		}
		
		return pt;
	}



	//accepts connection object, SQL Query,and user Object as a parameter.and sets to values & returns PreparedStatement object. 
	public static PreparedStatement update(Connection con, String up, Users u) {		
		try {
			pt = con.prepareStatement(up);
			pt.setString(1,u.getPremium_type());
			pt.setInt(2,u.getPno());
			} catch (SQLException e) {
			System.out.println("Error!!");
			e.printStackTrace();
		}		
		return pt;
	}



	//accepts connection object, SQL Query,and user Object as a parameter.and sets to values & returns PreparedStatement object.
	public static PreparedStatement delete(Connection con, String del, Users u) {
		try {
			pt = con.prepareStatement(del);
			pt.setInt(1,u.getPno());
		} catch (SQLException e) {
			System.out.println("Error!!");
			e.printStackTrace();
		} 
		return pt;
	}

}
