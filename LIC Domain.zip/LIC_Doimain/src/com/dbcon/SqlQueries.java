package com.dbcon;

public class SqlQueries {


		//SQL queries to insert, update,display and Delete
		public static final String insert="insert into tb_users "+ "(Policy_Name ,Policy_Holder_Name ,Policy_Start_Date ,Premium_Amount ,Premium_Type) values" + 
				"( ?,?,?,?,?)";
		public static final String update="update tb_users SET Premium_Type=?   where Policy_Number = ?";
		public static final String read="select * from tb_users where Policy_Number = ?";
		public static final String delete=" delete from tb_users  where Policy_Number = ?";
		
	}
	
	
	

