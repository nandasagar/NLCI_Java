package datatypes;

public class DataTypes {
	 public static void main(String[] args) {
	    	
	    	byte num1= 113;
	    	short num2=150;
	    	long num3 = -12332252626L;
	    	double num4 = -42937737.9d;	
	    	float num5 = 19.98f;
	    	boolean b = false;
	    	char ch = 'A';
	    	String str = "NTT DATA";
	    	System.out.println("Byte Data type :"+num1);
	    	System.out.println("Short Data type :"+num2);
	    	System.out.println("Long Data type :"+num3);
	    	System.out.println("Double Data type :"+num4);
	    	System.out.println("float Data type :"+num5);
	    	System.out.println("boolean Data type :"+b);
	    	System.out.println("Char Data type :"+ch);
	    	System.out.println("String Data type:"+str);
	    	
}
}