package strings;

public class StringCompare {

	public static void main(String args[]){ 
		
		System.out.println("*************CompareTo Function************");
		String s1="Ram";
		String s2="Ram"; 
		String s3="Sham"; 
		String s4="Ban";
		
		System.out.println(s1.compareTo(s2)); // BOTH ARE EQUAL
		System.out.println(s1.compareTo(s3)); // S1 IS Lesser THAN S3		
		System.out.println(s1.compareTo(s4));//S1  IS GREATER THAN S4

		
		System.out.println("*************EqualsIgnore Function************");
		String s5="hello"; 
		String s6="HELLO"; 
		String s7="hi";
		System.out.println(s5.equalsIgnoreCase(s6));   // returns true
		System.out.println(s5.equalsIgnoreCase(s7));   //returns false
		
		System.out.println("*************Equals Function************");
		String s8="Sagar"; 
		String s9="Sagar"; 
		String s10="Nanda";
		System.out.println(s8.equals(s9));   // returns true
		System.out.println(s8.equals(s10));   //returns false
		
		System.out.println("************* == Function************");
		String s11="java"; 
		String s12="zeva"; 
		String s13="java";
		System.out.println(s11==s12);   // returns false
		System.out.println(s11==s13);   //returns true
		
	}
} 