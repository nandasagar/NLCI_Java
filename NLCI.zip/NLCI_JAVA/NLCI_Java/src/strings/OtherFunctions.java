package strings;

import java.util.Scanner;

public class OtherFunctions {

	public static void main(String [] args)
	{ 
		Scanner s=new Scanner(System.in);
		

		System.out.println("****************************************************");
		System.out.println("isEmpty() Function ");
		String s3=""; 
		String s4="hello"; 
		System.out.println(s3.isEmpty());      // true
		System.out.println(s4.isEmpty());      // false


		System.out.println("****************************************************");
		System.out.println("toLowerCase() Function ");
	
		String s5="GOOD MORNING BANGALORE!";
		String lower=s5.toLowerCase();
		System.out.println(lower);
		
		
		System.out.println("****************************************************");
		System.out.println("toUpperCase() Function ");
		String s6="hello how are you";  
		String upper=s6.toUpperCase();  
		System.out.println(upper);  
		
		
		System.out.println("****************************************************");
		System.out.println("replace() Function ");
		String s7="NSS DASA "; 
		String replaceString=s7.replace('S','T'); 
		System.out.println(replaceString);
		
		
		System.out.println("****************************************************");
		System.out.println("Contains() Function ");
		String sen=" hello Good Morning .how are you .i hope very one are safe"; 
		System.out.println(sen.contains("how are you"));  // returns true
		System.out.println(sen.contains("hello"));        // returns true  
		System.out.println(sen.contains("Safe"));    
		
		
		System.out.println("****************************************************");
		System.out.println("trim() Function ");
		String s8="  hello   ";  
		System.out.println(s8+"how are you");        // without trim()  
		System.out.println(s8.trim()+"how are you"); //with trim()
		
		System.out.println("****************************************************");
		System.out.println("Concat Function ");
		System.out.println("Enter a sentence to concat with Hello World! ");
		String s2=s.next();
		String s1="hello World! ";
		s1=s1.concat(s2);
		System.out.println(s1);
			
	}
	
}
