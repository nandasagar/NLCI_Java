package strings;

public class StringLen {
	
		public static void main(String args[])
		{ 
		String s1="NTT DATA"; 
		String s2="Global Delivery Services"; 
		System.out.println("string length is: "+s1.length());  
		System.out.println("string length is: "+s2.length()); 
		}
}