package classes_and_Objects;

public class Example2 {

	public static void main(String[] args) {
		
		// Creating object of student class and assigning values
		Student s1=new Student("Nanda");
		s1.age(22);
		s1.address("Bangalore");
		s1.college("SVIT");
		s1.cgpa(7.75);
		s1.display();
		
		
	}

}
