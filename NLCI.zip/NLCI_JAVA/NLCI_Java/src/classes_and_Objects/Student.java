package classes_and_Objects;

public class Student {
	
	String name,address,college;
	int age;
	double cgpa;
	public Student(String name1) {
		// TODO Auto-generated constructor stub
		this.name=name1;
	}
	public void age(int age1) {
		// TODO Auto-generated method stub
		age=age1;
	}
	public void address(String address1) {
		// TODO Auto-generated method stub
		address=address1;
	}
	public void college(String college1) {
		// TODO Auto-generated method stub
		college=college1;
		
	}
	public void cgpa(double d) {
		// TODO Auto-generated method stub
		cgpa= d;
	}
	
	public void display()
	{
		  System.out.println("Name:"+ name );
	      System.out.println("Age:" + age );
	      System.out.println("Address:" + address );
	      System.out.println("college:" + college);
	      System.out.println("CGPA:" + cgpa);
	}

	
	
}
