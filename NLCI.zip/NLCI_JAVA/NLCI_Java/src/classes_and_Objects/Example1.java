package classes_and_Objects;

public class Example1 {

	int a=10;  //instance Variable
	public static void main(String[] args) {
	
		Example1 obj= new Example1(); // object creation 
		
		int b=obj.a + 10;
		int c=obj.a + b;
		
		// Displaying values 
		System.out.println("value of a ="+obj.a);
		System.out.println("value of b ="+b);
		System.out.println("value of c ="+c);
	}

}
