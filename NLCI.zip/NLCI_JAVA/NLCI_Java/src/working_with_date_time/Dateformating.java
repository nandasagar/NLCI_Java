package working_with_date_time;
import java.util.*;
import java.text.*;


public class Dateformating {

	   public static void main(String args[]) {
	      Date date = new Date( );

		   // display time and date using SimpleDateFormat
	      System.out.println("using SimpleDateFormat :");
	      SimpleDateFormat ft = new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz");

	      System.out.println("Todays Date: " + ft.format(date));
	      
	   // display time and date using printf
	      System.out.println("using printf :");
	      String str = String.format("Current Date/Time : %tc", date );

	      System.out.printf(str);
	      
	      
	   }
	}