package working_with_date_time;
import java.util.Date;
public class Todays_Date {

	   public static void main(String args[]) {
	      // Instantiate a Date object
	      Date date = new Date();

	      // displaying time and date using toString()
	      System.out.println(date.toString());
	   }
	}
	