package jdbc;

import java.util.Scanner;
import java.sql.*; 
import java.util.*; 

class Create 
{ 
    public static void main(String a[]) 
    { 
        //Creating the connection 
        String url = "jdbc:mysql://localhost:3306/dbEmp"; 
        String user = "root"; 
        String pass = "Nanda$105"; 
 
        //Entering the data 
        Scanner s = new Scanner(System.in); 
        System.out.println("enter name"); 
        String name = s.next(); 
        System.out.println("enter portal no"); 
        int portal = s.nextInt(); 
        System.out.println("enter Department"); 
        String dept =  s.next(); 
  
        //Inserting data using SQL query 
        String sql = "insert into employee values('"+name+"',"+portal+",'"+dept+"')"; 
        Connection con=null; 
        try
        { 
            DriverManager.registerDriver(new com.mysql.jdbc.Driver()); 
  
            //Reference to connection interface 
            con = DriverManager.getConnection(url,user,pass); 
  
            Statement st = con.createStatement(); 
            int m = st.executeUpdate(sql); 
            if (m == 1) 
                System.out.println("inserted successfully : "+sql); 
            else
                System.out.println("insertion failed"); 
            con.close(); 
        } 
        catch(Exception ex) 
        { 
            System.err.println(ex); 
        } 
    } 
} 