package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Read {
public static void main(String []args)
{
	
	 //Creating the connection 
    String url = "jdbc:mysql://localhost:3306/dbEmp"; 
    String user = "root"; 
    String pass = "Nanda$105"; 

    //Entering the data 
    Scanner s = new Scanner(System.in); 
   
    System.out.println("Values in database"); 
   
    //Inserting data using SQL query 
    String sql = "select * from employee"; 
    Connection conn = null;
    Statement stmt = null;
    try
    { 
        DriverManager.registerDriver(new com.mysql.jdbc.Driver()); 

        //Reference to connection interface 
        conn = DriverManager.getConnection(url,user,pass); 
      
       
        stmt = conn.createStatement();

     
        ResultSet rs = stmt.executeQuery(sql);
        //STEP 5: Extract data from result set
        while(rs.next()){
           //Retrieve by column name
         
           String name = rs.getString("name");
           int portal = rs.getInt("portal");
           String dept = rs.getString("dept");

           //Display values
           System.out.print("name: " + name);
           System.out.print(", portal: " + portal);
           System.out.print(", dept: " + dept);
       
        }
        rs.close();
 conn.close(); 
    } 
    catch(Exception ex) 
    { 
        System.err.println(ex); 
    } 
} 
} 
