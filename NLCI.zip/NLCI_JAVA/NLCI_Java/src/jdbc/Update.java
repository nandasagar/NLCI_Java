package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;

public class Update {


    public static void main(String a[]) 
    { 
        //Creating the connection 
        String url = "jdbc:mysql://localhost:3306/dbEmp"; 
        String user = "root"; 
        String pass = "Nanda$105"; 
        
        //Entering the data 
        Scanner s = new Scanner(System.in);  
        System.out.println("enter portal no which is to be Updated"); 
        int portal = s.nextInt(); 
        System.out.println("enter name"); 
        String name = s.next(); 
        System.out.println("enter Department"); 
        String dept =  s.next(); 
  
        Connection con=null; 
        try
        { 
            DriverManager.registerDriver(new com.mysql.jdbc.Driver()); 
  
            //Reference to connection interface 
            con = DriverManager.getConnection(url,user,pass); 
  
            Statement st = con.createStatement(); 
            PreparedStatement pt = con.prepareStatement(" update employee SET name = ?,dept =?\r\n" + 
    				" where portal = ?");	
    		pt.setString(1,name);
    		pt.setString(2,dept); 
    		pt.setInt(3, portal);
    		int r = pt.executeUpdate();
    		
    		st.close();
    	    con.close();
    	    if(r!=0)
    	    {
    	    	System.out.println("Updated");
    	    }
    	    else
    	    {
    	    	System.out.println("Invalid portal");
    	    }
    		
        } 
        catch(Exception ex) 
        { 
            System.err.println(ex); 
        } 
    } 
} 