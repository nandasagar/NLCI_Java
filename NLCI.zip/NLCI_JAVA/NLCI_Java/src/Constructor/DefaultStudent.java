package Constructor;
// Default Constructor
	class DefaultStudent{  
		int id;  
		String name;  
		//method to display the value of id and name  
		void display(){System.out.println(id+" "+name);}  
		  
		public static void main(String args[]){  
		//creating objects  
			DefaultStudent s1=new DefaultStudent();  
			DefaultStudent s2=new DefaultStudent();  
		//displaying values of the object  
			s1.display();  
			s2.display();  
		}  
		}  