package Constructor;

 class CopyStudent{  
	    int id;  
	    String name;  
	    CopyStudent(int i,String n){  
	    id = i;  
	    name = n;  
	    }  
	    CopyStudent(){
	    	
	    }  
	    void display()
	    {
	    	System.out.println(id+" "+name);
	    }  
	   
	    public static void main(String args[]){  
	    	CopyStudent s1 = new CopyStudent(111,"Karan");  
	    	CopyStudent s2 = new CopyStudent();  
	    s2.id=s1.id;  
	    s2.name=s1.name;  
	    s1.display();  
	    s2.display();  
	   }  
	}  