package inner_class;

	interface Age 
	{ 
	    int n = 23; 
	    void getAge(); 
	} 
	class AnonynmousClass 
	{ 
	    public static void main(String[] args) { 
	  
	        Age oj1 = new Age() { 
	            @Override
	            //Anonymous Inner Class
	            public void getAge() { 
	                 // printing  age 
	                System.out.print("Age is "+n); 
	            } 
	        }; 
	        oj1.getAge();
	        } 
	} 