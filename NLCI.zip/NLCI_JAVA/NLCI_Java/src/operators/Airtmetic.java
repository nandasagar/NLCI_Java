package operators;

import java.util.Scanner;

public class Airtmetic {

	static Scanner s=new Scanner(System.in);
public static void main(String []args)
 {
	    System.out.println();
	    System.out.println("Enter 2 numbers to perform Operations");
	    double a=s.nextDouble();
	    double b=s.nextDouble();
	    double result;
	        	
	            // Using addition operator
	            result = a + b;
	            System.out.println("a + b = " + result);
	        	
	            // Using subtraction operator
	            result = a - b;
	            System.out.println("a - b = " + result);
	        	
	            // Using multiplication operator
	            result = a * b;
	            System.out.println("a * b = " + result);

	            // Using division operator
	            result = a / b;
	            System.out.println("a / b = " + result);
	        	
	            // Using remainder operator
	            result = a % b;
	            System.out.println("a % b = " + result);
	        
	    }
	
}
