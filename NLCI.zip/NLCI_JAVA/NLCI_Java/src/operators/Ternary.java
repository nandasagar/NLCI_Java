package operators;

public class Ternary {
	public static void main(String[] args) {
    	
		int val1 = 10;
		int val2 = 20;
//largest of 2 values
		int max = val1 >= val2 ? val1 : val2;
	    	System.out.println("max of 2 values :"+max);
		       
}
	}
