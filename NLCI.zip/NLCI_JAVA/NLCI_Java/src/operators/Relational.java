package operators;

import java.util.Scanner;

public class Relational {
	
	static Scanner s=new Scanner(System.in);
	public static void main(String []args)
	 {
		    System.out.println();
		    System.out.println("Enter 2 numbers to perform Operations");
		    double a=s.nextDouble();
		    double b=s.nextDouble();
		    boolean result;
		        	
		            // Using > operator
		            result = a > b;
		            System.out.println("a > b = " + result);
		        	
		            // Using >= operator
		            result = a >= b;
		            System.out.println("a >= b = " + result);
		        	
		            // Using == operator
		            result = a == b;
		            System.out.println("a == b = " + result);

		            // Using < operator
		            result = a < b;
		            System.out.println("a < b = " + result);
		        	
		            // Using <= operator
		            result = a <= b;
		            System.out.println("a <=b = " + result);
		            
		         // Using != operator
		            result = a != b;
		            System.out.println("a != b = " + result);

		            
		            
		        
		    }
		
	}