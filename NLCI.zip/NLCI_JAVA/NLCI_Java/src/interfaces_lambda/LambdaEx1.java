package interfaces_lambda;

import java.util.ArrayList; 
class LambdaEx1 
{ 
    public static void main(String args[]) 
    { 
        int m=20;
        ArrayList<Integer> al = new ArrayList<Integer>(); 
        for(int i=1;i<=m;i++)
        {
        al.add(i); 
        }
  
        // Using lambda expression to print all elements 
        System.out.println("**********************************************");
        System.out.println("Printing all values");
         al.forEach(n -> System.out.println(n)); 
  
        // Using lambda expression to print even elements 
         System.out.println("**********************************************");
         System.out.println("Printing all Even  values");
        al.forEach(n -> { if (n%2 == 0) System.out.println(n); });
        

        // Using lambda expression to print odd elements 
        System.out.println("**********************************************");
        System.out.println("Printing all odd values");
        al.forEach(n -> { if (n%2 != 0) System.out.println(n); });
        
        
        
    } 
} 