package conditions_and_array;

import java.util.Scanner;

public class AllConditions_and_Loops {
	static Scanner s=new Scanner(System.in);
public static void main(String []args)
 {
	while(true) {
 
	int i;
	System.out.println("*****************************************");
	System.out.println(" Type 1 to perform if condition ");
	System.out.println(" Type 2 to perform if-else condition ");
	System.out.println(" Type 3 to perform while  loop ");
	System.out.println(" Type 4 to perform For Loop ");
	System.out.println(" Type 5 to perform Switch operation");
	System.out.println();
	System.out.println(" Enter 0 to Exit");
	System.out.println("*****************************************");
	
	i=s.nextInt();
	
	switch(i)
	{
	case 1: callingIf();
			break;
	
	case 2: callingIfElse();
			break;
			
	case 3: callingWhile();
	break;		
	
	case 4: callingFor();
	break;
	
	case 5: callingSwitch();
	break;
	
	case 0: System.exit(0);;
	break;
	
	default: System.out.println("Invalid ");
	
	}
	}
	
 }

private static void callingSwitch() {
	// TODO Auto-generated method stub
    System.out.println("*****************************************");
	System.out.println("Enter 1 to perform addition");
	System.out.println("Enter 2 to perform substraction ");
	System.out.println("Enter 3 to perform multiplication ");
	System.out.println("Enter 4 to perform division ");
	System.out.println("Enter 5 to perform modulus");
	System.out.println("*****************************************");
	int n=s.nextInt();
    System.out.println();
    System.out.println("Enter 2 numbers to perform Operations");
	int a=s.nextInt();
    int b=s.nextInt();
    
    // switch statement to check day
   
    switch (n) {
        case 1:
           System.out.println("sum of "+a+"+"+b+"="+(a+b));
            break;
        case 2:
        	  System.out.println("sub of "+"-"+"+"+b+"="+(a-b));
            break;
        case 3:
        	  System.out.println("mul of "+a+"*"+b+"="+(a*b));
            break;
        case 4:
        	  System.out.println("div of "+a+"/"+b+"="+(a/b));
            break;
        case 5:
        	  System.out.println("mod of "+a+"%"+b+"="+(a%b));
            break;
                default:
           System.out.println( "Invalid Value");
            break;
    }
}


private static void callingFor() {
	// TODO Auto-generated method stub
//printing values n time
	System.out.println("Enter n Value to perform Sum of n Numbers ");
	 int n = s.nextInt();
	 int sum = 0;


	    // for loop
	    for (int i = 1; i <= n; ++i) {
	      // body inside for loop
	      sum += i;     // sum = sum + i
	    }
		   
	    System.out.println("Sum = " + sum);
	  
	 
}

private static void callingWhile() {
	// TODO Auto-generated method stub
	 System.out.println("Enter n value to print the Statement n times");
	 int i = s.nextInt();
	   
     while (i >= 0) {
         System.out.println("NTT DATA " + i);
         i--;
     }
	
	
}

private static void callingIfElse() {
	// TODO Auto-generated method stub
	
	System.out.println("Enter your Age to know if you are Eligible to Drive or not");
	int age;
	age=s.nextInt();
	if(age>=18)
	{
		System.out.println("Yes you are Eligible");
	}
	else
	{
		System.out.println("No you are not Eligible");
	}
	
}

private static void callingIf() {
	// TODO Auto-generated method stub
	
	System.out.println("Enter your Age to know if you are Eligible to Vote in Election or not");
	int age;
	age=s.nextInt();
	if(age>=18)
	{
		System.out.println("Yes you are Eligible");
	}
	if(age<18)
	{
		System.out.println("No you are not Eligible");
	}
	
	
}
	
}
