package collections;
import java.util.HashSet;
import java.util.Iterator;

public class HashSetEx {

	public static void main(String args[]){  
		//Creating HashSet and adding elements  
		HashSet<String> set=new HashSet<String>();  
		set.add("Rahul");  
		set.add("Vijay");  
		set.add("Virat");  
		set.add("Vijay");  
		set.add("Abd");
		
		//Traversing elements  
		
		Iterator<String> itr=set.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next());  
		}  
	}  
}  