package collections;
import java.util.ArrayDeque;
import java.util.Deque;

public class ArrrayDequeEx {

	public static void main(String[] args) {  
		//Creating Deque and adding elements  
		Deque<String> dq = new ArrayDeque<String>();  
		dq.add("Nanda");  
		dq.add("Sagar");  
		dq.add("Sunil");
		dq.addFirst("Harsha");
		dq.addLast("Nitin");
		dq.add("dixit");
		System.out.println("Deque elements :"+dq);
		//Traversing elements  
		for (String str : dq) {  
		System.out.println(str);  
		}  
		}  
		}  