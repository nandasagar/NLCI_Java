package collections;
import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListEx {

	public static void main(String args[]){  
		LinkedList<String> al=new LinkedList<String>();  
		al.add("Ram");  
		al.add("Sham");  
		al.add("RCB");  
		al.add("Dam");
		System.out.println("List after adding 4 Elements: "+al);
		al.addFirst("Ayodhya");
		System.out.println("List after adding Ayodhya at First position: "+al);
		

		System.out.println();
		//iterator is used to perform iteration on al linked list to print their values one by one

		System.out.println("Printing Values of list one by one :");
		Iterator<String> itr=al.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next()); // printing the list values  
		}  
	}  
}  
