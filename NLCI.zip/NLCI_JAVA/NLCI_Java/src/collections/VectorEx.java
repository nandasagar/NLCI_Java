package collections;
import java.util.Iterator;
import java.util.Vector;

public class VectorEx {

	public static void main(String args[]){  
		Vector<String> v=new Vector<String>();  
		
		v.add("Virat"); 
		v.add("Rahul");  
		v.add("Mayank");   
		v.add("ABD"); 
		v.add("umesh");
		
		System.out.println("List Values :"+v);
		System.out.println();
		System.out.println("Does list contains Rahul :"+v.contains("Rahul"));
		System.out.println("Fisrt Element of the List :"+v.firstElement());
		System.out.println();
		System.out.println("Remove umesh from the List : ok");
		v.remove("umesh");
		System.out.println("After removing :"+v);

		System.out.println();
		System.out.println("Printing Values of list one by one :");
		Iterator<String> itr=v.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next());  
		}  
	}  
}  
