package collections;
import java.util.ArrayList;

public class ArrayListEx {


		public static void main(String[] args) 
		{ 

			// Declaring the ArrayList with 
		
			ArrayList <Integer>al 	= new ArrayList <Integer>(); 

			// Appending new elements
			for (int i = 1; i <= 5; i++) 
				al.add(i); 

			// Printing elements 
			System.out.println(" Array List before removing :"+al); 

			// Remove element at index 3 
			al.remove(3); 

			// Displaying the ArrayList 

			System.out.println();
			System.out.println(" Array List after removing :"+al); 
			System.out.println("Array list size : "+al.size());

			// Printing elements one by one using for loop  

			System.out.println("Printing elements one by one using for loop  \r\n");
			for (int i = 0; i < al.size(); i++) 
				System.out.print(al.get(i) + " "); 
		}


	} 

