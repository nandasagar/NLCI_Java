package oops_concepts;

	class Telephone {

		   public void call() {
		      System.out.println("I can call");
		   } 
		   
		}

		class Mobile extends Telephone {
		   public void chat() {
		      System.out.println("I can chat");
		   }

		public void playGame() {
			// TODO Auto-generated method stub
			 System.out.println("I can play Game");
		}
		}

		class Inheritance {
		   public static void main(String[] args) {

		      Mobile mob = new Mobile();
		      mob.call();
		      mob.chat();
		      mob.playGame();
		   }
		}