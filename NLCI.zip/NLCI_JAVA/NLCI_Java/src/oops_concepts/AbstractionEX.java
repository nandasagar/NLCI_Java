package oops_concepts;

	abstract class Animal {
		   abstract void makeSound();
		   abstract void eat();
		}

		class Dog extends Animal {
		   @Override
		   public void makeSound() {
		      System.out.println("Bark bark.");
		   }

		@Override
		public void eat() {
			System.out.println("Eats Pedigree");
		}
		}

		class Cat extends Animal {
			@Override
			public void makeSound() {
		      System.out.println("Meows ");
		   }

		@Override
		public void eat() {
			System.out.println("Eats Chicken");
		}
		}

		class AbstractionEX {
		   public static void main(String[] args) {
		      Dog d1 = new Dog();
		      d1.makeSound();
		      d1.eat();

		      Cat c1 = new Cat();
		      c1.makeSound();
		      c1.eat();
		   }
		}