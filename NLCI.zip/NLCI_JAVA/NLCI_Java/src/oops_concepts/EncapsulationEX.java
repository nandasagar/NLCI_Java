package oops_concepts;


class Encapsulation
{ 
 private String name; 
 private int portal; 
 private int age; 

 public int getAge()  
 { 
   return age; 
 } 

 public String getName()  
 { 
   return name; 
 } 
   
 public int getPortal()  
 { 
    return portal; 
 } 

public void setAge( int newAge) 
 { 
   age = newAge; 
 } 

 public void setName(String newName) 
 { 
   name = newName; 
 } 
   
 public void setPortal( int newPortal)  
 { 
   portal = newPortal; 
 } 
} 



public class EncapsulationEX
{     
    public static void main (String[] args)  
    { 
        Encapsulation obj = new Encapsulation(); 
    
        // setting values of the variables  
        obj.setName("Nanda Sagar"); 
        obj.setAge(23); 
        obj.setPortal(201146); 
          
        // Displaying values of the variables 
        System.out.println("Employee name: " + obj.getName()); 
        System.out.println("Employee age: " + obj.getAge()); 
        System.out.println("Employee portal: " + obj.getPortal()); 
        
    } 
}