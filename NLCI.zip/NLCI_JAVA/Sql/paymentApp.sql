#Creating Database

create database financeApp;
use  financeApp;

##Creating the table user under finance app
CREATE TABLE  users (
  name varchar(20) NOT NULL ,
  address varchar(35)NOT NULL,
  pan varchar(35) Not NULL,
  phone varchar(15) NOT NULL,
  country varchar(25) NOT NULL,
  PRIMARY KEY (phone)
);
###Inserting values into the table

INSERT INTO users (name,address,pan,phone,country) VALUES
( 'Ram', 'Bangalore ', '0ss54354', '022-258163 ', 'india'),
( 'Sham', 'Wdsac ', '0ss54124', '071-2581343 ', 'SA'),
( 'rhoit', 'chennai ', '0ss53354', '027-5873   ', 'india'),
( 'adan', 'Texas ', '0ss54554', '0799-2563   ', 'usa'),
( 'dadad', 'mumbai ', '0ss55554', '057-258463   ', 'india'),
( 'Rasuar', 'Texas ', '0ss66354', '47-2589763   ', 'usa'),
( 'shet', 'queens ', '0ss54774', '07-2581963   ', 'ENG'),
( 'bomba', 'Texas ', '0ss57554', '087-2542563   ', 'usa'),
( 'sundar', 'Mangalore ', '0s555354', '977-5834763   ', 'india');
# to Drop
drop table users;


#To display
Select * from users;

#the basic syntax of the SELECT statement with the WHERE clause is as shown below.
SELECT name, address, pan 
FROM users
WHERE country= "india";

#The basic syntax of an ALTER TABLE command to add a New Column in an existing table is as follows.
ALTER TABLE users ADD Balance varchar(30);

#The basic syntax of an update TABLE 
UPDATE users SET Balance = '75000' where address="india";
UPDATE users SET Balance = '50000' where country="SA";
UPDATE users SET Balance = '175000' where country="usa";
UPDATE users SET Balance = '25000' where country="ENG";
#Like
#Finds any values starts with ra
SELECT * FROM users
WHERE name LIKE 'ra%';

#Finds any values   with 5 any where
 SELECT * FROM users
 WHERE pan LIKE '%5%';
 
#Finds any values that end with 2.
SELECT * FROM users
 WHERE pan LIKE '%2';
 
 # AND and OR
 
 SELECT name,address 
FROM users
WHERE Balance > 50000 AND Balance < 100000;

 SELECT name,address 
FROM users
WHERE Balance > 75000 OR Balance < 100000;

# Order By Clause in Ascending
 SELECT * FROM users
   ORDER BY name;
   
# Order By Clause in Descending
 SELECT * FROM users
   ORDER BY name DESC;
  
# Group By Clause 
 SELECT name, Balance FROM users
   GROUP BY name;
   
 #DISTINCT Clause 
 SELECT DISTINCT Balance FROM users
   ORDER BY Balance;
   