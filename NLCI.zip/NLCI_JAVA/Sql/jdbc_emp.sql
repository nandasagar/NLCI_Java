create database dbEmp;
use dbEmp;
create  table employee(name varchar(40) not null,
portal integer primary key not null ,dept varchar(40) not null);
select * from employee;